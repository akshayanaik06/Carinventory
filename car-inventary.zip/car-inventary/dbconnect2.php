<?php
 class Dbconnection
 {
    public $oCon;
    public $oDB;
    public $sqlquery;
    public $result;


    public function __construct()
    {
        $server = 'localhost';
        $user = 'root';
        $password = '';
        $database = 'car_inventary';
        $this->oCon = mysqli_connect($server,$user,$password) or die("No connection");
        $this->oDB = mysqli_select_db($this->oCon,$database) or die('No databse connected');
    }

    public function execQuery($query)
    {
        $this->sqlquery = $query;
        $this->result = mysqli_query($this->oCon,$this->$sqlquery) or die("Error in query");
    }

    public function freeMemory()
    {
        return mysqli_free_result($this->result);

    }

    public function closeconn()
    {
        return mysqli_close($this->oCon);
    }
 }


?>