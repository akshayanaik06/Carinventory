<!DOCTYPE html>
<html>
<html lang="en">
     <head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
	    <meta name="viewport" content="width=device-width, initial-scale=1">
	    <title>Car Inventary System</title>
	    <meta name="description" content="Sports-All types of sports" />
	    <meta name="keywords" content="cricket,Football,Volleybal" />
	    <link rel="shortcut icon" href="">

	    <link rel="stylesheet" href="./assets/Bootstraps/css/bootstrap.css">
       

        
        <link rel="stylesheet" href="./assets/stylesheet/style.css">
       
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="./assets/dist/css/dash.min.css">
        <link rel="stylesheet" href="./assets/dist/css/skins/_all-skins.min.css">
       
        <!-- jvectormap -->
        <link rel="stylesheet" href="./assets/plugins/jvectormap/jquery-jvectormap-1.2.2.css">
      
        
       
          <link rel="stylesheet" type="text/css" href="./assets/sweetalert/sweetalert.css">
    </head>
    <body >
      <!-- CUSTOM JQUERY SCRIPT  -->
     
