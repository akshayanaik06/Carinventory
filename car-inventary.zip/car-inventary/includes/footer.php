<script src="./assets/js/jquery-1.11.2.min.js"></script>
<script type="text/javascript" src="./assets/Bootstraps/js/bootstrap.js"></script> 
<script src="./assets/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="./assets/plugins/fastclick/fastclick.min.js"></script>
<script src="./assets/dist/js/app.min.js"></script>
<script src="./assets/dist/js/demo.js"></script>
<script src="./assets/sweetalert/sweetalert.min.js"></script>

 
 <script type="text/javascript" src="admin_script.js"></script>                 

</body>
</html>